import{g as e}from"./index-ZoLAjoZl.js";var o=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")};const r=e(o),s=Object.freeze(Object.defineProperty({__proto__:null,default:r},Symbol.toStringTag,{value:"Module"}));export{s as b};
//# sourceMappingURL=browser-CjolKMPn.js.map
