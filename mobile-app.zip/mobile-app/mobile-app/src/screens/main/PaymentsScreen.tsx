import React, { useEffect, useState } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  RefreshControl,
  Text,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { api } from "../../services/api";
import { CreditCard, TrendingUp, Check, Clock, AlertCircle } from "lucide-react-native";

const PaymentsScreen = ({ navigation }: any) => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({ total: 0, pending: 0 });

  useEffect(() => {
    loadPayments();
  }, []);

  const loadPayments = async () => {
    try {
      const data = await api.getPayments();
      setPayments(data);

      const total = data.reduce((sum: number, p: any) => sum + (p.amount || 0), 0);
      const pending = data.filter((p: any) => p.status === "pending").length;

      setStats({ total, pending });
    } catch (error) {
      console.error("Error loading payments:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadPayments();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <Check color="#10b981" size={20} />;
      case "pending":
        return <Clock color="#f59e0b" size={20} />;
      default:
        return <AlertCircle color="#ef4444" size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "#dcfce7";
      case "pending":
        return "#fef3c7";
      default:
        return "#fee2e2";
    }
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#3b82f6" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <TrendingUp color="#3b82f6" size={24} />
          <Text style={styles.statValue}>${(stats.total / 100).toFixed(2)}</Text>
          <Text style={styles.statLabel}>Total Revenue</Text>
        </View>
        <View style={styles.statCard}>
          <Clock color="#f59e0b" size={24} />
          <Text style={styles.statValue}>{stats.pending}</Text>
          <Text style={styles.statLabel}>Pending</Text>
        </View>
      </View>

      {/* Payments List */}
      <FlatList
        data={payments}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.paymentCard}
            onPress={() => navigation.navigate("PaymentDetail", { payment: item })}
          >
            <View style={styles.cardHeader}>
              <View
                style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}
              >
                {getStatusIcon(item.status)}
              </View>
              <View style={styles.cardInfo}>
                <Text style={styles.paymentTitle}>{item.description}</Text>
                <Text style={styles.paymentDate}>
                  {new Date(item.createdAt).toLocaleDateString()}
                </Text>
              </View>
              <Text style={styles.paymentAmount}>${(item.amount / 100).toFixed(2)}</Text>
            </View>
          </TouchableOpacity>
        )}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <CreditCard color="#d1d5db" size={48} />
            <Text style={styles.emptyText}>No payments yet</Text>
          </View>
        }
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  centerContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  statsContainer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  statValue: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
    marginVertical: 8,
  },
  statLabel: {
    fontSize: 12,
    color: "#6b7280",
    textAlign: "center",
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  paymentCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  statusBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  cardInfo: {
    flex: 1,
  },
  paymentTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111827",
    marginBottom: 2,
  },
  paymentDate: {
    fontSize: 12,
    color: "#9ca3af",
  },
  paymentAmount: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111827",
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: "#6b7280",
    marginTop: 16,
  },
});

export default PaymentsScreen;
