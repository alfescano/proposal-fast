import React, { useEffect, useState } from "react";
import {
  View,
  ScrollView,
  StyleSheet,
  RefreshControl,
  Text,
  TouchableOpacity,
} from "react-native";
import { useAuthStore } from "../../store/authStore";
import { api } from "../../services/api";
import { TrendingUp, Zap, Clock } from "lucide-react-native";

const DashboardScreen = ({ navigation }: any) => {
  const { user } = useAuthStore();
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    totalProposals: 0,
    totalRevenue: 0,
    pendingContracts: 0,
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Load proposals
      const proposals = await api.getProposals();
      const payments = await api.getPayments();

      const totalRevenue = payments.reduce(
        (sum: number, p: any) => sum + (p.amount || 0),
        0
      );

      setStats({
        totalProposals: proposals.length,
        totalRevenue,
        pendingContracts: proposals.filter((p: any) => p.status === "pending")
          .length,
      });
    } catch (error) {
      console.error("Error loading dashboard:", error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      {/* Welcome Header */}
      <View style={styles.header}>
        <Text style={styles.welcomeText}>Welcome, {user?.name}</Text>
        <Text style={styles.subtitleText}>Here's your activity overview</Text>
      </View>

      {/* Stats Cards */}
      <View style={styles.statsGrid}>
        <StatCard
          title="Total Proposals"
          value={stats.totalProposals.toString()}
          icon={<TrendingUp color="#3b82f6" size={24} />}
          color="#e0f2fe"
        />
        <StatCard
          title="Revenue"
          value={`$${(stats.totalRevenue / 100).toFixed(2)}`}
          icon={<TrendingUp color="#10b981" size={24} />}
          color="#ecfdf5"
        />
        <StatCard
          title="Pending"
          value={stats.pendingContracts.toString()}
          icon={<Clock color="#f59e0b" size={24} />}
          color="#fffbeb"
        />
      </View>

      {/* Quick Actions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => navigation.navigate("Contracts")}
        >
          <Zap color="#fff" size={20} />
          <Text style={styles.actionButtonText}>Generate Contract</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.actionButton, styles.actionButtonSecondary]}
          onPress={() => navigation.navigate("Proposals")}
        >
          <Text style={styles.actionButtonTextSecondary}>View Proposals</Text>
        </TouchableOpacity>
      </View>

      {/* Recent Activity */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Activity</Text>
        <View style={styles.activityItem}>
          <Text style={styles.activityText}>
            No recent activity yet. Get started by creating a contract!
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

// Stat Card Component
const StatCard = ({ title, value, icon, color }: any) => (
  <View style={[styles.statCard, { backgroundColor: color }]}>
    <View style={styles.statIcon}>{icon}</View>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={styles.statTitle}>{title}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  welcomeText: {
    fontSize: 28,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 4,
  },
  subtitleText: {
    fontSize: 14,
    color: "#6b7280",
  },
  statsGrid: {
    paddingHorizontal: 12,
    marginBottom: 24,
    gap: 12,
  },
  statCard: {
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
  },
  statIcon: {
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 4,
  },
  statTitle: {
    fontSize: 12,
    color: "#6b7280",
    fontWeight: "500",
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#111827",
    marginBottom: 12,
  },
  actionButton: {
    backgroundColor: "#3b82f6",
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginBottom: 10,
  },
  actionButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  actionButtonSecondary: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  actionButtonTextSecondary: {
    color: "#111827",
    fontSize: 16,
    fontWeight: "600",
  },
  activityItem: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  activityText: {
    fontSize: 14,
    color: "#6b7280",
  },
});

export default DashboardScreen;
