import React, { useState } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Text,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { api } from "../../services/api";
import { useOfflineStore } from "../../store/offlineStore";
import { FileText, Send, Download } from "lucide-react-native";

const ContractGeneratorScreen = () => {
  const [contractType, setContractType] = useState("service");
  const [clientName, setClientName] = useState("");
  const [freelancerName, setFreelancerName] = useState("");
  const [projectScope, setProjectScope] = useState("");
  const [budget, setBudget] = useState("");
  const [timeline, setTimeline] = useState("");
  const [loading, setLoading] = useState(false);
  const [contract, setContract] = useState("");

  const { addOfflineAction, isOnline } = useOfflineStore();

  const handleGenerateContract = async () => {
    if (!clientName || !freelancerName || !projectScope || !budget || !timeline) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    try {
      setLoading(true);

      const contractData = {
        contractType,
        clientName,
        freelancerName,
        projectScope,
        budget,
        timeline,
      };

      if (isOnline) {
        const result = await api.generateContract(contractData);
        setContract(result.contract);
      } else {
        // Save for later when online
        await addOfflineAction("contract", "create", contractData);
        Alert.alert(
          "Saved Offline",
          "Your contract will be generated when you're back online"
        );
      }
    } catch (error) {
      Alert.alert("Error", "Failed to generate contract");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSendForSignature = async () => {
    if (!contract) {
      Alert.alert("Error", "Generate a contract first");
      return;
    }

    try {
      setLoading(true);

      const result = await api.sendToSignWell({
        contractText: contract,
        contractName: `${clientName} - ${projectScope}`,
        recipients: [
          { name: clientName, email: clientName.toLowerCase() + "@example.com" },
        ],
      });

      Alert.alert("Success", "Contract sent for signature!");
    } catch (error) {
      Alert.alert("Error", "Failed to send for signature");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <FileText color="#3b82f6" size={32} />
          <Text style={styles.title}>Generate Contract</Text>
          <Text style={styles.subtitle}>
            Create professional contracts with AI
          </Text>
        </View>

        {!contract ? (
          <>
            {/* Contract Type Selector */}
            <View style={styles.section}>
              <Text style={styles.label}>Contract Type</Text>
              <View style={styles.typeButtons}>
                {["service", "freelance", "nda"].map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[
                      styles.typeButton,
                      contractType === type && styles.typeButtonActive,
                    ]}
                    onPress={() => setContractType(type)}
                  >
                    <Text
                      style={[
                        styles.typeButtonText,
                        contractType === type && styles.typeButtonTextActive,
                      ]}
                    >
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Form Fields */}
            <View style={styles.section}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Client Name</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter client name"
                  value={clientName}
                  onChangeText={setClientName}
                  editable={!loading}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Freelancer/Provider Name</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Your name"
                  value={freelancerName}
                  onChangeText={setFreelancerName}
                  editable={!loading}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Project Scope</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Describe the work to be done"
                  value={projectScope}
                  onChangeText={setProjectScope}
                  editable={!loading}
                  multiline
                  numberOfLines={3}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Budget</Text>
                <TextInput
                  style={styles.input}
                  placeholder="$5000"
                  value={budget}
                  onChangeText={setBudget}
                  editable={!loading}
                  keyboardType="decimal-pad"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Timeline</Text>
                <TextInput
                  style={styles.input}
                  placeholder="30 days"
                  value={timeline}
                  onChangeText={setTimeline}
                  editable={!loading}
                />
              </View>
            </View>

            {/* Generate Button */}
            <TouchableOpacity
              style={[styles.button, loading && styles.buttonDisabled]}
              onPress={handleGenerateContract}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <FileText color="#fff" size={20} />
                  <Text style={styles.buttonText}>Generate Contract</Text>
                </>
              )}
            </TouchableOpacity>
          </>
        ) : (
          <>
            {/* Generated Contract Display */}
            <View style={styles.contractBox}>
              <Text style={styles.contractTitle}>Generated Contract</Text>
              <ScrollView style={styles.contractContent}>
                <Text style={styles.contractText}>{contract}</Text>
              </ScrollView>
            </View>

            {/* Action Buttons */}
            <TouchableOpacity
              style={styles.button}
              onPress={handleSendForSignature}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Send color="#fff" size={20} />
                  <Text style={styles.buttonText}>Send for Signature</Text>
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, styles.buttonSecondary]}
              onPress={() => setContract("")}
            >
              <FileText color="#3b82f6" size={20} />
              <Text style={styles.buttonTextSecondary}>Generate New</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  content: {
    padding: 16,
  },
  header: {
    alignItems: "center",
    marginBottom: 32,
    paddingVertical: 20,
    backgroundColor: "#eff6ff",
    borderRadius: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: "#111827",
    marginTop: 12,
  },
  subtitle: {
    fontSize: 14,
    color: "#6b7280",
    marginTop: 4,
  },
  section: {
    marginBottom: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111827",
    marginBottom: 8,
  },
  typeButtons: {
    flexDirection: "row",
    gap: 8,
  },
  typeButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: 6,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  typeButtonActive: {
    backgroundColor: "#3b82f6",
    borderColor: "#3b82f6",
  },
  typeButtonText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#6b7280",
    textAlign: "center",
  },
  typeButtonTextActive: {
    color: "#fff",
  },
  inputGroup: {
    marginBottom: 16,
  },
  input: {
    backgroundColor: "#fff",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: "#111827",
  },
  textArea: {
    minHeight: 80,
    paddingTop: 10,
  },
  button: {
    backgroundColor: "#3b82f6",
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginBottom: 12,
  },
  buttonDisabled: {
    backgroundColor: "#93c5fd",
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  buttonSecondary: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  buttonTextSecondary: {
    color: "#3b82f6",
    fontSize: 16,
    fontWeight: "600",
  },
  contractBox: {
    backgroundColor: "#fff",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    padding: 16,
    marginBottom: 20,
    maxHeight: 400,
  },
  contractTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
  },
  contractContent: {
    flex: 1,
  },
  contractText: {
    fontSize: 12,
    color: "#374151",
    lineHeight: 18,
  },
});

export default ContractGeneratorScreen;
