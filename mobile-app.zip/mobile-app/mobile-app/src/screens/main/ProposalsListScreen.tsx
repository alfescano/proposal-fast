import React, { useEffect, useState } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  RefreshControl,
  Text,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { api } from "../../services/api";
import { FileText, ChevronRight, Plus } from "lucide-react-native";

const ProposalsListScreen = ({ navigation }: any) => {
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadProposals();
  }, []);

  const loadProposals = async () => {
    try {
      const data = await api.getProposals();
      setProposals(data);
    } catch (error) {
      console.error("Error loading proposals:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadProposals();
  };

  const handleProposalPress = (proposal: any) => {
    navigation.navigate("ProposalDetail", { proposal });
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#3b82f6" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={proposals}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.proposalCard}
            onPress={() => handleProposalPress(item)}
          >
            <View style={styles.cardHeader}>
              <FileText color="#3b82f6" size={24} />
              <View style={styles.cardInfo}>
                <Text style={styles.proposalTitle}>{item.title}</Text>
                <Text style={styles.proposalClient}>Client: {item.clientName}</Text>
              </View>
              <ChevronRight color="#9ca3af" size={20} />
            </View>

            <View style={styles.cardDetails}>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Amount:</Text>
                <Text style={styles.detailValue}>${item.amount}</Text>
              </View>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Status:</Text>
                <Text
                  style={[
                    styles.detailValue,
                    item.status === "accepted"
                      ? styles.statusAccepted
                      : item.status === "pending"
                        ? styles.statusPending
                        : styles.statusRejected,
                  ]}
                >
                  {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <FileText color="#d1d5db" size={48} />
            <Text style={styles.emptyText}>No proposals yet</Text>
            <Text style={styles.emptySubtext}>Create your first proposal</Text>
          </View>
        }
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  centerContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  listContent: {
    padding: 16,
  },
  proposalCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 12,
  },
  cardInfo: {
    flex: 1,
  },
  proposalTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 2,
  },
  proposalClient: {
    fontSize: 12,
    color: "#6b7280",
  },
  cardDetails: {
    flexDirection: "row",
    gap: 16,
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
    paddingTop: 12,
  },
  detailItem: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 12,
    color: "#9ca3af",
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111827",
  },
  statusAccepted: {
    color: "#10b981",
  },
  statusPending: {
    color: "#f59e0b",
  },
  statusRejected: {
    color: "#ef4444",
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#6b7280",
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: "#9ca3af",
    marginTop: 4,
  },
});

export default ProposalsListScreen;
