import React from "react";
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from "react-native";
import { FileText, Download, Share2 } from "lucide-react-native";

const ContractDetailScreen = ({ route }: any) => {
  const { contract } = route.params || {};

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <FileText color="#3b82f6" size={32} />
          <Text style={styles.title}>Contract Details</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.contractText}>
            {contract?.text || "Contract content will be displayed here"}
          </Text>
        </View>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.button}>
            <Download color="#fff" size={20} />
            <Text style={styles.buttonText}>Download</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.buttonSecondary]}>
            <Share2 color="#3b82f6" size={20} />
            <Text style={styles.buttonSecondaryText}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  content: {
    padding: 16,
  },
  header: {
    alignItems: "center",
    marginBottom: 24,
    paddingVertical: 24,
    backgroundColor: "#eff6ff",
    borderRadius: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#111827",
    marginTop: 12,
  },
  section: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    minHeight: 300,
  },
  contractText: {
    fontSize: 13,
    color: "#374151",
    lineHeight: 20,
  },
  actions: {
    gap: 12,
  },
  button: {
    backgroundColor: "#3b82f6",
    borderRadius: 8,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  buttonSecondary: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  buttonSecondaryText: {
    color: "#3b82f6",
    fontSize: 16,
    fontWeight: "600",
  },
});

export default ContractDetailScreen;
