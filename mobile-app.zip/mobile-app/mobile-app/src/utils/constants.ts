// API Configuration
export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || "https://app.proposalfast.ai";
export const API_TIMEOUT = 15000; // 15 seconds
export const MAX_RETRIES = 3;
export const RETRY_DELAY = 1000; // 1 second

// Storage Keys
export const STORAGE_KEYS = {
  AUTH_TOKEN: "authToken",
  USER: "user",
  OFFLINE_ACTIONS: "offlineActions",
  DEVICE_TOKEN: "deviceToken",
  LAST_SYNC: "lastSync",
} as const;

// Contract Types
export const CONTRACT_TYPES = [
  { id: "service", label: "Service Agreement" },
  { id: "freelance", label: "Freelance Agreement" },
  { id: "nda", label: "NDA" },
  { id: "employment", label: "Employment Agreement" },
  { id: "partnership", label: "Partnership Agreement" },
] as const;

// Proposal Statuses
export const PROPOSAL_STATUSES = {
  DRAFT: "draft",
  PENDING: "pending",
  ACCEPTED: "accepted",
  REJECTED: "rejected",
  EXPIRED: "expired",
} as const;

// Payment Statuses
export const PAYMENT_STATUSES = {
  PENDING: "pending",
  PROCESSING: "processing",
  COMPLETED: "completed",
  FAILED: "failed",
  REFUNDED: "refunded",
} as const;

// User Roles
export const USER_ROLES = {
  FREELANCER: "freelancer",
  CLIENT: "client",
  ADMIN: "admin",
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: "Network error. Please check your connection.",
  TIMEOUT: "Request timed out. Please try again.",
  UNAUTHORIZED: "Unauthorized. Please log in again.",
  SERVER_ERROR: "Server error. Please try again later.",
  INVALID_INPUT: "Invalid input. Please check your data.",
  NOT_FOUND: "Resource not found.",
  UNKNOWN_ERROR: "An unknown error occurred.",
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  CONTRACT_GENERATED: "Contract generated successfully!",
  CONTRACT_SENT: "Contract sent for signature!",
  PROPOSAL_CREATED: "Proposal created successfully!",
  PAYMENT_PROCESSED: "Payment processed successfully!",
  PROFILE_UPDATED: "Profile updated successfully!",
} as const;

// Validation Rules
export const VALIDATION = {
  MIN_PASSWORD_LENGTH: 8,
  MAX_PASSWORD_LENGTH: 128,
  MIN_NAME_LENGTH: 2,
  MAX_NAME_LENGTH: 100,
  MIN_AMOUNT: 1,
  MAX_AMOUNT: 999999999,
} as const;

// Timeouts
export const TIMEOUTS = {
  SHORT: 3000, // 3 seconds
  MEDIUM: 5000, // 5 seconds
  LONG: 10000, // 10 seconds
} as const;

// Cache Duration
export const CACHE_DURATION = {
  SHORT: 5 * 60 * 1000, // 5 minutes
  MEDIUM: 30 * 60 * 1000, // 30 minutes
  LONG: 24 * 60 * 60 * 1000, // 24 hours
} as const;

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 10,
  MAX_PAGE_SIZE: 100,
} as const;

// Date Formats
export const DATE_FORMATS = {
  SHORT: "MMM dd, yyyy",
  LONG: "MMMM dd, yyyy",
  TIME: "hh:mm aa",
  DATETIME: "MMM dd, yyyy hh:mm aa",
} as const;

// Currency
export const CURRENCY = {
  USD: "USD",
  EUR: "EUR",
  GBP: "GBP",
} as const;

// Feature Flags
export const FEATURE_FLAGS = {
  OFFLINE_MODE: true,
  PUSH_NOTIFICATIONS: true,
  CAMERA_SCANNING: true,
  BIOMETRIC_AUTH: true,
} as const;
