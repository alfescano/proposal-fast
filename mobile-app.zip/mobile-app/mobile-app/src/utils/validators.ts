/**
 * Validate email format
 */
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate password strength
 */
export const validatePassword = (password: string): {
  isValid: boolean;
  errors: string[];
} => {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push("Password must be at least 8 characters");
  }
  if (!/[A-Z]/.test(password)) {
    errors.push("Password must contain uppercase letter");
  }
  if (!/[a-z]/.test(password)) {
    errors.push("Password must contain lowercase letter");
  }
  if (!/[0-9]/.test(password)) {
    errors.push("Password must contain number");
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

/**
 * Validate name
 */
export const validateName = (name: string): boolean => {
  return name.trim().length >= 2 && name.trim().length <= 100;
};

/**
 * Validate phone number
 */
export const validatePhoneNumber = (phone: string): boolean => {
  const phoneRegex = /^[\d\s\-\(\)\+]+$/;
  const cleaned = phone.replace(/\D/g, "");
  return phoneRegex.test(phone) && cleaned.length >= 10;
};

/**
 * Validate URL
 */
export const validateURL = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

/**
 * Validate currency amount
 */
export const validateAmount = (
  amount: number,
  min: number = 1,
  max: number = 999999999
): boolean => {
  return amount >= min && amount <= max && !isNaN(amount);
};

/**
 * Validate credit card number (Luhn algorithm)
 */
export const validateCardNumber = (cardNumber: string): boolean => {
  const cleaned = cardNumber.replace(/\s/g, "");

  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }

  // Luhn algorithm
  let sum = 0;
  let isEven = false;

  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
};

/**
 * Validate expiration date
 */
export const validateExpirationDate = (
  month: number,
  year: number
): boolean => {
  if (month < 1 || month > 12) {
    return false;
  }

  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth() + 1;

  if (year < currentYear) {
    return false;
  }

  if (year === currentYear && month < currentMonth) {
    return false;
  }

  return true;
};

/**
 * Validate CVV
 */
export const validateCVV = (cvv: string): boolean => {
  return /^\d{3,4}$/.test(cvv);
};

/**
 * Validate file size
 */
export const validateFileSize = (
  sizeInBytes: number,
  maxSizeInMB: number = 10
): boolean => {
  return sizeInBytes <= maxSizeInMB * 1024 * 1024;
};

/**
 * Validate file type
 */
export const validateFileType = (
  filename: string,
  allowedTypes: string[]
): boolean => {
  const extension = filename.split(".").pop()?.toLowerCase();
  return extension ? allowedTypes.includes(extension) : false;
};

/**
 * Validate date range
 */
export const validateDateRange = (
  startDate: Date,
  endDate: Date
): boolean => {
  return startDate <= endDate;
};

/**
 * Validate required field
 */
export const validateRequired = (value: any): boolean => {
  if (typeof value === "string") {
    return value.trim().length > 0;
  }
  return value != null && value !== undefined;
};

/**
 * Validate JSON
 */
export const validateJSON = (jsonString: string): boolean => {
  try {
    JSON.parse(jsonString);
    return true;
  } catch {
    return false;
  }
};

/**
 * Validate minimum length
 */
export const validateMinLength = (value: string, minLength: number): boolean => {
  return value.length >= minLength;
};

/**
 * Validate maximum length
 */
export const validateMaxLength = (value: string, maxLength: number): boolean => {
  return value.length <= maxLength;
};

/**
 * Validate contract data
 */
export const validateContractData = (data: {
  clientName?: string;
  freelancerName?: string;
  projectScope?: string;
  budget?: string;
  timeline?: string;
}): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};

  if (!data.clientName || !validateRequired(data.clientName)) {
    errors.clientName = "Client name is required";
  }

  if (!data.freelancerName || !validateRequired(data.freelancerName)) {
    errors.freelancerName = "Freelancer name is required";
  }

  if (!data.projectScope || !validateRequired(data.projectScope)) {
    errors.projectScope = "Project scope is required";
  }

  if (!data.budget || !validateRequired(data.budget)) {
    errors.budget = "Budget is required";
  }

  if (!data.timeline || !validateRequired(data.timeline)) {
    errors.timeline = "Timeline is required";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

/**
 * Validate proposal data
 */
export const validateProposalData = (data: {
  title?: string;
  description?: string;
  amount?: number;
}): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};

  if (!data.title || !validateRequired(data.title)) {
    errors.title = "Title is required";
  }

  if (!data.description || !validateRequired(data.description)) {
    errors.description = "Description is required";
  }

  if (!data.amount || !validateAmount(data.amount)) {
    errors.amount = "Valid amount is required";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};
