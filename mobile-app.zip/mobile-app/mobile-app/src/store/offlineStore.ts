import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";
import NetInfo from "@react-native-community/netinfo";

interface OfflineAction {
  id: string;
  type: "contract" | "proposal" | "payment";
  action: "create" | "update" | "delete";
  data: any;
  timestamp: number;
  synced: boolean;
}

interface OfflineStore {
  isOnline: boolean;
  pendingActions: OfflineAction[];
  syncInProgress: boolean;

  // Offline methods
  addOfflineAction: (
    type: OfflineAction["type"],
    action: OfflineAction["action"],
    data: any
  ) => Promise<void>;
  getPendingActions: () => Promise<OfflineAction[]>;
  syncPendingActions: () => Promise<void>;
  clearSyncedActions: () => Promise<void>;
  initializeOfflineStore: () => Promise<void>;
  updateOnlineStatus: (isOnline: boolean) => void;
}

export const useOfflineStore = create<OfflineStore>((set, get) => ({
  isOnline: true,
  pendingActions: [],
  syncInProgress: false,

  addOfflineAction: async (
    type: OfflineAction["type"],
    action: OfflineAction["action"],
    data: any
  ) => {
    try {
      const newAction: OfflineAction = {
        id: `${Date.now()}-${Math.random()}`,
        type,
        action,
        data,
        timestamp: Date.now(),
        synced: false,
      };

      const existing = await AsyncStorage.getItem("offlineActions");
      const actions = existing ? JSON.parse(existing) : [];
      actions.push(newAction);

      await AsyncStorage.setItem("offlineActions", JSON.stringify(actions));
      set((state) => ({
        pendingActions: [...state.pendingActions, newAction],
      }));
    } catch (error) {
      console.error("Error adding offline action:", error);
    }
  },

  getPendingActions: async () => {
    try {
      const actions = await AsyncStorage.getItem("offlineActions");
      return actions ? JSON.parse(actions) : [];
    } catch (error) {
      console.error("Error getting pending actions:", error);
      return [];
    }
  },

  syncPendingActions: async () => {
    const { isOnline, pendingActions } = get();

    if (!isOnline || pendingActions.length === 0) {
      return;
    }

    set({ syncInProgress: true });

    try {
      for (const action of pendingActions) {
        if (action.synced) continue;

        try {
          // Sync to backend based on action type
          const endpoint = `https://app.proposalfast.ai/api/${action.type}s`;
          const method =
            action.action === "create" ? "POST" : action.action === "update" ? "PUT" : "DELETE";

          const response = await fetch(endpoint, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(action.data),
          });

          if (response.ok) {
            action.synced = true;
          }
        } catch (error) {
          console.error(`Error syncing ${action.type}:`, error);
          // Continue with next action
        }
      }

      // Save updated actions
      const unsyncedActions = pendingActions.filter((a) => !a.synced);
      await AsyncStorage.setItem(
        "offlineActions",
        JSON.stringify(unsyncedActions)
      );

      set({ pendingActions: unsyncedActions });
    } finally {
      set({ syncInProgress: false });
    }
  },

  clearSyncedActions: async () => {
    try {
      const actions = await AsyncStorage.getItem("offlineActions");
      if (!actions) return;

      const allActions = JSON.parse(actions);
      const unsyncedActions = allActions.filter((a: OfflineAction) => !a.synced);

      await AsyncStorage.setItem(
        "offlineActions",
        JSON.stringify(unsyncedActions)
      );

      set({ pendingActions: unsyncedActions });
    } catch (error) {
      console.error("Error clearing synced actions:", error);
    }
  },

  initializeOfflineStore: async () => {
    try {
      // Monitor network status
      const unsubscribe = NetInfo.addEventListener((state) => {
        set({ isOnline: state.isConnected ?? true });

        // Auto-sync when coming online
        if (state.isConnected) {
          get().syncPendingActions();
        }
      });

      // Get initial pending actions
      const actions = await get().getPendingActions();
      set({ pendingActions: actions });

      return () => unsubscribe();
    } catch (error) {
      console.error("Error initializing offline store:", error);
    }
  },

  updateOnlineStatus: (isOnline: boolean) => {
    set({ isOnline });
    if (isOnline) {
      get().syncPendingActions();
    }
  },
}));
