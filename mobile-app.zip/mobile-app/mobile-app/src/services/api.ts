import axios, { AxiosInstance } from "axios";
import * as SecureStore from "expo-secure-store";

const API_BASE_URL = "https://app.proposalfast.ai";

class APIClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 15000,
    });

    // Add token to requests
    this.client.interceptors.request.use(async (config) => {
      const token = await SecureStore.getItemAsync("authToken");
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    // Handle errors
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Token expired, clear auth
          SecureStore.deleteItemAsync("authToken");
        }
        throw error;
      }
    );
  }

  // ===== CONTRACTS =====

  async generateContract(params: {
    contractType: string;
    clientName: string;
    freelancerName: string;
    projectScope: string;
    budget: string;
    timeline: string;
  }) {
    const response = await this.client.post("/api/generate-contract", params);
    return response.data;
  }

  async sendToSignWell(params: {
    contractText: string;
    contractName: string;
    recipients: Array<{ name: string; email: string }>;
  }) {
    const response = await this.client.post("/api/send-to-signwell", params);
    return response.data;
  }

  // ===== PROPOSALS =====

  async getProposals() {
    const response = await this.client.get("/api/proposals");
    return response.data;
  }

  async getProposal(id: string) {
    const response = await this.client.get(`/api/proposals/${id}`);
    return response.data;
  }

  async createProposal(data: any) {
    const response = await this.client.post("/api/proposals", data);
    return response.data;
  }

  async updateProposal(id: string, data: any) {
    const response = await this.client.put(`/api/proposals/${id}`, data);
    return response.data;
  }

  async deleteProposal(id: string) {
    await this.client.delete(`/api/proposals/${id}`);
  }

  // ===== PAYMENTS =====

  async createCheckoutSession(params: { proposalId: string; amount: number }) {
    const response = await this.client.post("/api/payments/checkout", params);
    return response.data;
  }

  async getPayments() {
    const response = await this.client.get("/api/payments");
    return response.data;
  }

  async getPayment(id: string) {
    const response = await this.client.get(`/api/payments/${id}`);
    return response.data;
  }

  async confirmPayment(params: { paymentIntentId: string }) {
    const response = await this.client.post("/api/payments/confirm", params);
    return response.data;
  }

  // ===== FILES =====

  async uploadFile(file: File, type: "contract" | "proposal" | "document") {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("type", type);

    const response = await this.client.post("/api/files/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  }

  async downloadFile(fileId: string) {
    const response = await this.client.get(`/api/files/${fileId}/download`, {
      responseType: "blob",
    });
    return response.data;
  }

  // ===== NOTIFICATIONS =====

  async registerPushToken(token: string) {
    const response = await this.client.post("/api/notifications/register", {
      token,
    });
    return response.data;
  }

  async getNotifications() {
    const response = await this.client.get("/api/notifications");
    return response.data;
  }

  // ===== HEALTH CHECK =====

  async healthCheck() {
    const response = await this.client.get("/health");
    return response.data;
  }
}

export const api = new APIClient();
