import { CameraView, useCameraPermissions } from "expo-camera";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system";

class CameraService {
  async requestCameraPermission() {
    const [permission, requestPermission] = useCameraPermissions();
    
    if (!permission?.granted) {
      const { granted } = await requestPermission();
      return granted;
    }
    
    return permission.granted;
  }

  async requestPhotoLibraryPermission() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    return status === "granted";
  }

  async pickImageFromLibrary() {
    const hasPermission = await this.requestPhotoLibraryPermission();
    if (!hasPermission) {
      throw new Error("Camera roll permission not granted");
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.8,
      base64: true,
    });

    if (!result.canceled) {
      return result.assets[0];
    }

    return null;
  }

  async pickMultipleImages() {
    const hasPermission = await this.requestPhotoLibraryPermission();
    if (!hasPermission) {
      throw new Error("Camera roll permission not granted");
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultiple: true,
      quality: 0.8,
    });

    if (!result.canceled) {
      return result.assets;
    }

    return [];
  }

  async saveImageToCache(uri: string): Promise<string> {
    try {
      const filename = uri.split("/").pop() || `image-${Date.now()}.jpg`;
      const cacheDir = FileSystem.cacheDirectory;
      const filePath = `${cacheDir}${filename}`;

      await FileSystem.copyAsync({
        from: uri,
        to: filePath,
      });

      return filePath;
    } catch (error) {
      console.error("Error saving image to cache:", error);
      throw error;
    }
  }

  async deleteImageFromCache(filePath: string) {
    try {
      await FileSystem.deleteAsync(filePath);
    } catch (error) {
      console.error("Error deleting image:", error);
    }
  }

  async getImageDimensions(uri: string): Promise<{ width: number; height: number }> {
    try {
      const base64 = await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      // Get dimensions from image file
      const img = new Image();
      img.src = `data:image/jpeg;base64,${base64}`;

      return {
        width: img.width,
        height: img.height,
      };
    } catch (error) {
      console.error("Error getting image dimensions:", error);
      throw error;
    }
  }

  async compressImage(uri: string, quality: number = 0.7): Promise<string> {
    try {
      const filename = `compressed-${Date.now()}.jpg`;
      const cacheDir = FileSystem.cacheDirectory;
      const filePath = `${cacheDir}${filename}`;

      // Read and manipulate image
      const base64 = await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      await FileSystem.writeAsStringAsync(filePath, base64, {
        encoding: FileSystem.EncodingType.Base64,
      });

      return filePath;
    } catch (error) {
      console.error("Error compressing image:", error);
      throw error;
    }
  }
}

export const cameraService = new CameraService();
