import * as Notifications from "expo-notifications";
import * as Device from "expo-device";
import { api } from "./api";

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

class NotificationService {
  async registerForPushNotifications() {
    if (!Device.isDevice) {
      console.log("Must use physical device for notifications");
      return null;
    }

    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== "granted") {
      console.log("Failed to get push notification permission");
      return null;
    }

    try {
      const token = await Notifications.getExpoPushTokenAsync();
      // Register token with backend
      await api.registerPushToken(token.data);
      return token.data;
    } catch (error) {
      console.error("Error getting push token:", error);
      return null;
    }
  }

  async sendLocalNotification(
    title: string,
    body: string,
    data?: Record<string, any>
  ) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: data || {},
      },
      trigger: null, // Send immediately
    });
  }

  async scheduleNotification(
    title: string,
    body: string,
    secondsFromNow: number,
    data?: Record<string, any>
  ) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: data || {},
      },
      trigger: {
        seconds: secondsFromNow,
      },
    });
  }

  async cancelAllNotifications() {
    await Notifications.cancelAllScheduledNotificationsAsync();
  }

  async cancelNotification(notificationId: string) {
    await Notifications.dismissNotificationAsync(notificationId);
  }

  onNotificationResponse(
    callback: (notification: Notifications.Notification) => void
  ) {
    return Notifications.addNotificationResponseReceivedListener((event) => {
      callback(event.notification);
    });
  }

  onNotificationReceived(
    callback: (notification: Notifications.Notification) => void
  ) {
    return Notifications.addNotificationReceivedListener((notification) => {
      callback(notification);
    });
  }
}

export const notificationService = new NotificationService();
