import { initStripe, PlatformPay } from "@stripe/stripe-react-native";

const STRIPE_PUBLIC_KEY = process.env.EXPO_PUBLIC_STRIPE_PUBLIC_KEY;

class StripeService {
  async initialize() {
    if (!STRIPE_PUBLIC_KEY) {
      console.error("Stripe public key not configured");
      return false;
    }

    try {
      await initStripe({
        publishableKey: STRIPE_PUBLIC_KEY,
        merchantIdentifier: "merchant.com.proposalfast",
        threeDSecureParams: {
          timeout: 5 * 60 * 1000, // 5 minutes
        },
      });
      return true;
    } catch (error) {
      console.error("Stripe initialization failed:", error);
      return false;
    }
  }

  async isApplePayAvailable(): Promise<boolean> {
    try {
      return await PlatformPay.isApplePaySupported();
    } catch {
      return false;
    }
  }

  async isGooglePayAvailable(): Promise<boolean> {
    try {
      return await PlatformPay.isGooglePaySupported();
    } catch {
      return false;
    }
  }

  async validateCardDetails(cardDetails: {
    number: string;
    expMonth: number;
    expYear: number;
    cvc: string;
  }): Promise<boolean> {
    try {
      // Validate card format
      if (!cardDetails.number || cardDetails.number.length < 13) {
        return false;
      }

      if (!cardDetails.cvc || cardDetails.cvc.length < 3) {
        return false;
      }

      if (cardDetails.expMonth < 1 || cardDetails.expMonth > 12) {
        return false;
      }

      const currentYear = new Date().getFullYear();
      if (cardDetails.expYear < currentYear) {
        return false;
      }

      return true;
    } catch {
      return false;
    }
  }

  async formatCardNumber(cardNumber: string): Promise<string> {
    // Remove spaces and format as XXXX XXXX XXXX XXXX
    const cleaned = cardNumber.replace(/\s/g, "");
    const chunks = cleaned.match(/.{1,4}/g) || [];
    return chunks.join(" ");
  }

  getCardBrand(cardNumber: string): string {
    const number = cardNumber.replace(/\s/g, "");

    if (/^4[0-9]{12}(?:[0-9]{3})?$/.test(number)) {
      return "Visa";
    } else if (/^5[1-5][0-9]{14}$/.test(number)) {
      return "Mastercard";
    } else if (/^3[47][0-9]{13}$/.test(number)) {
      return "Amex";
    } else if (/^6(?:011|5[0-9]{2})[0-9]{12}$/.test(number)) {
      return "Discover";
    }

    return "Unknown";
  }

  async handlePaymentResult(result: any): Promise<{
    success: boolean;
    error?: string;
  }> {
    if (!result) {
      return {
        success: false,
        error: "Payment was cancelled",
      };
    }

    if (result.error) {
      return {
        success: false,
        error: result.error.message,
      };
    }

    return {
      success: true,
    };
  }
}

export const stripeService = new StripeService();
